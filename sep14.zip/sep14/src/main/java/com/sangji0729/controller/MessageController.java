package com.sangji0729.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.sangji0729.service.MessageService;

@Controller
public class MessageController {
	@Resource(name="messageService")
	private MessageService messageService;
	
	@RequestMapping(value="/message.do")
	public ModelAndView messageList(HttpServletRequest request) {
		ModelAndView mv = new ModelAndView("message");
		HttpSession session = request.getSession();
		Map<String, Object> map = new HashMap<String, Object>();
		
		if(session.getAttribute("sm_id") != null) {
			//데이터베이스 질의문
			map.put("sm_id", session.getAttribute("sm_id"));
			List<Map<String, Object>> list = messageService.messageList(map);
			mv.addObject("list", list);
			System.out.println("리스트" + list);
		}else {
			//비로그인시 로그인.do 화면으로
			mv.setViewName("redirect:/login.do");
		}
		
		
		return mv;
	}
}
