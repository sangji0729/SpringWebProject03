package com.sangji0729.controller;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.sangji0729.common.CommandMap;
import com.sangji0729.service.TestService;
import com.sangji0729.service.TestServiceImp;

@Controller
public class TestController {
	
	@Resource(name="testService")
	private TestServiceImp testService;
	
	@RequestMapping(value = "/main.do")
	public ModelAndView main(){
		ModelAndView mv = new ModelAndView("main");
		List<Map<String, Object>> list = testService.boardList();
		//System.out.println(list);
		mv.addObject("list", list);
		
		
		return mv;
	}
	
	
	
	@RequestMapping("/detail.do")
	public ModelAndView detail(CommandMap map) {
		//mv객체 만들기
		ModelAndView mv = new ModelAndView("detail");
		
		//DB에 질의하기. ~에 담기
		//서비스에게 질의를 던질 때 commandMap을 던지는 것이 아니라 그 속에 map만 뽑아서 던집니다
		Map<String, Object> detail = testService.detail(map.getMap());
		System.out.println("map : " + map);
		System.out.println("map.getMap() : "+map.getMap());
		System.out.println("detail : " + detail);
		//mv에 붙이기
		mv.addObject("detail", detail);
		//spring 생명주기, 커낵션 풀
		
		//return
		
		return mv;
	}
	
	@RequestMapping("/delete.do")
	public String delete(CommandMap map) {
		//해야 할 일?
		//System.out.println("map : " + map.getMap()); sl_no값이 넘어옴
		testService.delete(map.getMap());
		
		String url = "redirect:/main.do";
		
		return url;
	}
}
