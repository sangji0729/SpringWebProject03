package com.sangji0729.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

@Repository("messageDAO")
public class MessageDAO extends AbstractDAO {

	
	public List<Map<String, Object>> messageList(Map<String, Object> map) {
		return selectList("message.messageList", map);
	}
	
}
