package com.sangji0729.service;

import java.util.Map;

public interface JoinService {
	public int join(Map<String, Object> map);
}
