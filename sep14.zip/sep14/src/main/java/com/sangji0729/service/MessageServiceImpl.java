package com.sangji0729.service;

import java.util.List;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sangji0729.dao.MessageDAO;

@Service("messageService")
public class MessageServiceImpl implements MessageService {

	@Autowired
	private MessageDAO messageDAO;
	
	@Override
	public List<Map<String, Object>> messageList(Map<String, Object> map) {
		return messageDAO.messageList(map);
	}

	@Override
	public Map<String, Object> readMessage(Map<String, Object> map) {
		return null;
	}

	@Override
	public int sendMessage(Map<String, Object> map) {
		return 0;
	}

	@Override
	public int checkMessage(Map<String, Object> map) {
		return 0;
	}

	@Override
	public int deleteMessage(Map<String, Object> map) {
		return 0;
	}

}
