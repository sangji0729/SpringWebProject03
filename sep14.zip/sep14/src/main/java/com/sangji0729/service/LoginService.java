package com.sangji0729.service;

import java.util.Map;

public interface LoginService {
	
	public Map<String, Object> login(Map<String, Object> map);
}
